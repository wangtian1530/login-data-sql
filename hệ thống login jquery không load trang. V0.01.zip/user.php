<div class="jumbotron">
  <h1>xin chào : <?= $_SESSION['username'];?></h1> 
  <p>password: <?=$_SESSION['password'];?></p>
  <p>md5: <?= $_SESSION['md5'];?></p>
  <a class="" id="out" href="#logout">thoát</a>
</div>