<script type="text/javascript" charset="utf-8">
    window.location = "index.php";
</script>